import express from "express";
import multer from "multer";
import fetch from "node-fetch";

const app = express();
const upload = multer({ dest: "uploads/" });

const WEBHOOK_URL = "https://discord.com/api/webhooks/1464010816163545256/O89pseGM8_qhEyf68fYEAwkJrqYx8XXrvKCncmyEJtmLnuENuGu6lezMfURhlyrfuNS1";

app.use(express.static("public"));

app.post("/comprar", upload.single("comprovante"), async (req, res) => {
  const { discord, produto, valor } = req.body;

  const embed = {
    title: "🛒 Nova Compra • Capital RP",
    color: 0x8b0000,
    fields: [
      { name: "👤 Discord", value: discord },
      { name: "📦 Produto", value: produto, inline: true },
      { name: "💰 Valor", value: valor, inline: true },
      { name: "💸 PIX", value: "11966662323" },
      { name: "📌 Aviso", value: "Abrir ticket para receber o benefício" }
    ],
    timestamp: new Date()
  };

  await fetch(WEBHOOK_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ embeds: [embed] })
  });

  res.json({ ok: true });
});

app.listen(3000, () => console.log("Loja online"));
